package com.recruitmentportal.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecruitmentPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecruitmentPortalApplication.class, args);
		System.out.println("In Recruitment app");
		
	}

}
