package com.recruitmentportal.main.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.recruitmentportal.main.pojo.FileDetails;
import com.recruitmentportal.main.service.FileDetailsServiceInterface;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("hrportalapi")
public class FileDetailsController {

	@Autowired
	private FileDetailsServiceInterface detailsServiceInterface;

	@RequestMapping(value = "addnewfiledetails", method = RequestMethod.POST)
	public FileDetails addNewFileDetails(@RequestParam("file") MultipartFile file) {
		FileDetails fileDetails = new FileDetails();
		fileDetails.setFileName(StringUtils.cleanPath(file.getOriginalFilename()));
		fileDetails.setFileType(file.getContentType());
		try {
			fileDetails.setDocument(file.getBytes());
		} catch (IOException e) {
			System.out.println("Exception while file upload");
		}

		return detailsServiceInterface.addNewFileDetails(fileDetails);

	}

}
