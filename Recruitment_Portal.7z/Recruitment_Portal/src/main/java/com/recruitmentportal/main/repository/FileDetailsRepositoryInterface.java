package com.recruitmentportal.main.repository;

import com.recruitmentportal.main.pojo.FileDetails;

public interface FileDetailsRepositoryInterface {

	public FileDetails addNewFileDetails(FileDetails fileDetails);

}
