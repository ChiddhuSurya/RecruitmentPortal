package com.recruitmentportal.main.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.recruitmentportal.main.pojo.FileDetails;

@Repository
public class FileDetailsRepository implements FileDetailsRepositoryInterface {

	private static final String ADD_NEW_FILE_DETAILS = "INSERT INTO file_details VALUES(?,?,?,?)";
	
	private static final String GET_FILE_ID = "SELECT 'F'||file_details_sequence.NEXTVAL FROM DUAL"; 

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public FileDetails addNewFileDetails(FileDetails fileDetails) {

		String id= jdbcTemplate.queryForObject(GET_FILE_ID , String.class);
				
		fileDetails.setFileId(id);
		Object[] args = { fileDetails.getFileId() , fileDetails.getFileName(), fileDetails.getFileType(),fileDetails.getDocument() };
		jdbcTemplate.update(ADD_NEW_FILE_DETAILS, args);

		
		return fileDetails;
	}

}
