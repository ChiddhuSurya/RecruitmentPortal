package com.recruitmentportal.main.service;

import org.springframework.stereotype.Service;

import com.recruitmentportal.main.pojo.FileDetails;

public interface FileDetailsServiceInterface {

	
	public FileDetails addNewFileDetails(FileDetails fileDetails);
}
